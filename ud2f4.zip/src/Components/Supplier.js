import React from "react";
import ReactDOM from "react-dom";
import "./Aboutus.css";


function Supplier() {
  return (
<div>
<div className="header" />
<div className="content" />
<div className="footer">
        <div className="footertext">
            <p>
            <div className="navbar-logo">
              Metal Allies
            </div>
            </p>
            <p>
              Powerpils BV<br></br>
              Residentie Rotzooi<br></br>
              Enschede GP Skyboxlaan 123A<br></br>
              1234 AB Enschede<br></br>
            </p>
            <p>
            info@metal-allies.com<br></br>
            06-123456
            </p>
          </div>
          </div>
</div>

);
}

export default Supplier;